--------------------------
BirdWingData version 2.1
CSV format (tidy data)

updated on 04 July, 2024
--------------------------

[How to cite this dataset]
- Shiomi, K., Tatani, M., Kikuchi, D.M. (2024) BirdWingData: wingspan and wing area data of birds compiled from multiple literature sources and original measurements. Ecological Research, DOI:10.1111/1440-1703.12502

- Shiomi, K., Tatani, M., Kikuchi, D.M. (2024) Data from: BirdWingData: wingspan and wing area data of birds compiled from multiple literature sources and original measurements. figshare, DOI:10.6084/m9.figshare.23537892


[Acknowledgements]
We are grateful to Yasuyuki Saito for his cooperation in correcting the dataset and to Jun Hosoya and Yawara Takeda for their help in obtaining photos of the Northern Boobook wings.


[Datafiles in BirdWingData]
・"ReadMe.txt": This file

・"BirdWingData_tidy.csv": Main file
Wingspan, wing area, body mass, and additonal data for each species are listed. "NA" means that no specific information is provided in the cited literature.
***** Please first check "HeaderInfo-BirdWingData.txt" for details ***** 

・"ReferenceList.csv": Information of cited literature
"NA" means that no specific information exists for the data source.
***** Please first check "HeaderInfo-Reference.txt" for details ***** 

・"SpeciesList.csv": List of included species
Taxonomy follows IOC World Bird List (v13.1).

・"OrderCoverage.csv": Information of the inclusion proportion for each order
Taxonomy follows IOC World Bird List (v13.1).

・"FamilyCoverage.csv": Information of the inclusion proportion for each family
Taxonomy follows IOC World Bird List (v13.1).

・"(first author's surname)_(year).csv" in "EachDataset" folder: Individual tables of wingspans and/or wing areas copied from the cited papers
These files are included to share CSV-formatted data when the original files were published in PDF format. Please see the original literatures for details of the tables.


[Notes]
* When using any data from BirdWingData, please cite the literature providing the original data, in addition to our data paper. Note that the literature cited in BirdWingData often compiles data originally published in other papers.

* Definitions of "wingspan" and "wing area" vary across studies, and some papers do not clearly mention their definitions. Please check "ReferenceList.csv" and "HeaderInfo-Reference.csv" for the definitions used in each paper.


[Contact]
wing.measurement@gmail.com

* If you find any mistakes or have suggestions for improvement, please inform the authors.


